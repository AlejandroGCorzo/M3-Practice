"use strict";

var express = require("express");

var router = express.Router();
module.exports = router;


const models = require("../models/model");


// escriban sus rutas acá
// siéntanse libres de dividir entre archivos si lo necesitan
router.get('/houses', (req, res) => {
    res.json(models.listHouses())
});

router.post('/houses', (req, res) => {
    res.json(models.addHouse(req.body.family))
});

router.get('/characters', (req, res) => {
    res.json(models.listCharacters())
});


