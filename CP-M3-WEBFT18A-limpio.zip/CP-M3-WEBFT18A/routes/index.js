'use strict';

const express = require('express');
const { listFamilies } = require('../models/model.js');
const router = express.Router();
const model = require('../models/model.js');

module.exports = router;

// escriban sus rutas acá:
// siéntanse libres de dividir entre archivos si lo necesitan
